# Deriv TickLab

Application web statique en un seul fichier (`index.html`).

## Lancer
Ouvrir `index.html` dans un navigateur moderne. Une connexion Internet est nécessaire pour Google Fonts et le flux public Deriv.

## Publier gratuitement depuis un téléphone avec GitHub Pages
1. Ouvrir https://github.com dans Chrome et créer un compte ou se connecter.
2. Appuyer sur `+` puis `New repository`.
3. Nommer le dépôt `deriv-ticklab`, choisir `Public`, puis créer le dépôt.
4. Choisir `Add file` > `Upload files`.
5. Envoyer le fichier `index.html` extrait de cette archive ZIP.
6. Appuyer sur `Commit changes`.
7. Ouvrir `Settings` du dépôt > `Pages`.
8. Dans `Build and deployment`, choisir `Deploy from a branch`.
9. Choisir la branche `main` et le dossier `/ (root)`, puis `Save`.
10. Attendre quelques minutes. GitHub affichera l'adresse publique dans la page Pages, généralement `https://VOTRE-PSEUDO.github.io/deriv-ticklab/`.

## Notes
- L'application n'envoie aucun ordre et ne demande aucun token, mot de passe ou dépôt.
- Le journal de simulation est conservé localement dans le navigateur (localStorage).
- Les calculs statistiques et indicateurs décrivent l'historique visible; ils ne prédisent pas les prochains ticks.
- Le flux dépend de la disponibilité de l'API publique Deriv et de l'autorisation d'accès depuis le navigateur.
- Les indices 1 seconde sont identifiés par les symboles `1HZ10V`, `1HZ25V`, `1HZ50V`, `1HZ75V`, `1HZ100V`.
